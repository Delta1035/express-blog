export type Comment = {
jump_url: string
id: number
email: string
content: string
create_time: Date
site_url: string
nick_name: string
article_id: number
approved: number
deleted: number
avatar: string
device: string
}