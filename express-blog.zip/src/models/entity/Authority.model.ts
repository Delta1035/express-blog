export type Authority = {
    auth_name: string
    id: number
    auth_description: string
    parent_auth_id: number
}