export type ArticleCategory = {
    id:number,
    article_id:number,
    category_id:number
}