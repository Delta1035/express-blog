export type MyResponse<T> = {
    code: number,
    msg: string,
    data: T
}