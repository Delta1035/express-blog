export type RoleAuth = {
    id:number,
    role_id:number,
    auth_id:number
}
