export type Banner = {
    id: number
    poster: string
    link: string
    name: string
    type: number
    prefer_position: string
}